<?php
require "config.php";
include "header.php";

//data form forms
$inputusername = $_POST['username'];
$inputpassword = $_POST['password'];
$searchusername = "SELECT player_id, username, password FROM player";
$result = $conn->query($searchusername);


if ($result ->num_rows > 0) {
    // this check what the entered username is
  //loop checking each row for the input username
  while($row = $result->fetch_assoc()) {
    if ($row["username"] === $inputusername){
      if ($row["password"] === $inputpassword){
        $passwordcheck = true;
        break;
        } else {
          $passwordcheck = false;
          $error = "Sorry incorrect password";
          break;
        }      
      } else {
        $passwordcheck = false;
        //bug testing //echo "not the user entered " . $row["username"] . "<br>";
      }
    }
  }
//checks if username is not in the database
if ($row["username"] !== $inputusername) {
  //echo "Sorry this user isnt reconginsed ";
  $error = "Sorry this user isnt reconginsed ";
}

if ($passwordcheck === true){
  if (session_id() == '') {
    session_start();
    }
  $_SESSION["username"] = $row["username"];
  $_SESSION["password"] = $row["password"];
  $_SESSION["type"] = "player";
  $_SESSION["id"] = $row["player_id"];
  unset($_SESSION["loginerr"]);
  //echo "session created!";
  header("Location: index.php");
  exit();
} else {
  //echo "error something is wrong";
  header("Location: Loginpage.php");
  $_SESSION["loginerr"] = $error;
}


$conn->close();
?>