<!DOCTYPE html>
<?php
require "config.php";
include "header.php";

//queries for region and games
$searchregion = "SELECT * FROM region";
$searchgame = "SELECT * FROM games";
$searchtimezone ="SELECT * FROM timezone";

$resultregion = $conn->query($searchregion);
$resultgame = $conn->query($searchgame);
$resulttimezone = $conn->query($searchtimezone);
?>
<head>
        <title>Sign up</title>
</head>

<body>

<h1>Sign up page</h1>
<!--this is to switch between player and coach forms-->
<button onclick="showcoach()">Coach</button>
<button onclick="showplayer()">Player</button>


<!--this is for the coach form-->
<form id="coach-form" action="newcoachaccount.pro.php" onsubmit="return validatecoachform()" method="post">
  <h3>Coach</h3>
<!--username field-->
<div class="signup-forms">

<label for="username">Username:</label><br>
<input type="text" id="username" name="username"><br>
<!--password field-->
<label for="password">Password:</label><br>
<input id="coachpassword" type="password" name="password"><br>
<!--confirm password field-->
<label for="confirmpassword">Confirm Password:</label><br>
<input id="coachconfirm" type="password" name="confirmpassword"><br>
<input type="checkbox" onclick="togglecoachpassword()">Show Password<br>
<!--region field-->
<label for="region">Region:</label><br>
<select id="region" name="region">
<option value="" selected disabled hidden>Select Region</option>

<?php
$resultregion->data_seek(0);
if ($resultregion ->num_rows > 0) { 
        while ($rowregion = $resultregion ->fetch_assoc()) {
                     echo "<option value=" . $rowregion['region_name'] . " title='" . $rowregion['region_full_name'] . "' >" . $rowregion['region_name'] . "</option>";       
        }
        echo "</select>" . "<br>";
}
?>

<span>
    <a href="regionpage.php">What server am i in?</a><br>
</span>
<!--description field-->
<label for= "description">Description:</label><br>
<textarea name="description" rows="5" cols="40"></textarea><br>
<!--game field-->
<label for="games">Game of choice: </label><br>
<select id="games" name="games">
  <option value="" selected disabled hidden>Choose game</option>
  <?php
        $resultgame->data_seek(0);
        if ($resultgame ->num_rows > 0) {
                while ($rowgame = $resultgame ->fetch_assoc()){
                        echo "<option value" . $rowgame['games_name'] . " title='" . $rowgame['games_full_name'] . "' >" . $rowgame['games_name'] . "</option>";
                }
                echo "</select>" . "<br>";
        }
  ?>
</select><br>
</div>
<!--fields for timezone-->
<div class="timetable-form">
<b>Timetable</b> <br>
<label for="timezone">Timezone:</label>
<select id="timezone" name="timezone">
        <option value="" selected disabled hidden>Select Timezone</option>
        <?php
        $resulttimezone->data_seek(0);
        if ($resulttimezone ->num_rows > 0) {        
                while ($rowzone = $resulttimezone ->fetch_assoc()) {
                        if ($rowzone['timezone_name'] === $currenttimezone){
                        echo "<option value=" . $rowzone['timezone_offset'] . " selected>" . $rowzone['timezone_name'] . "</option>";  
                        }
                else {
                     echo "<option value=" . $rowzone['timezone_offset'] . " >" . $rowzone['timezone_name'] . "</option>";   
                }
                
        }
        echo "</select>" . "<br>";
        }
?>

<!--fields for each day for the timetable-->
<b>Sunday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="sun_start" name="sun_start" onchange="setSuncoach()"> 
<label for="sun_end">end-time</label> 
<input type="time" id="sun_end" name="sun_end"> <br>

<b>Monday</b> <br>
<label for="mon_start">start-time</label>
<input type="time" id="mon_start" name="mon_start" onchange="setMoncoach()">
<label for="mon_end">end-time</label> 
<input type="time" id="mon_end" name="mon_end"><br>

<b>Tuesday</b> <br>
<label for="tue_start">start-time</label>
<input type="time" id="tue_start" name="tue_start" onchange="setTuecoach()">
<label for="tue_end">end-time</label> 
<input type="time" id="tue_end" name="tue_end"> <br>

<b>Wendesday</b> <br>
<label for="wed_start">start-time</label>
<input type="time" id="wed_start" name="wed_start" onchange="setWedcoach()"> 
<label for="wed_end">end-time</label>
<input type="time" id="wed_end" name="wed_end"> <br>

<b>Thursday</b> <br>
<label for="thu_start">start-time</label>
<input type="time" id="thu_start" name="thu_start" onchange="setThucoach()"> 
<label for="thu_end">end-time</label>
<input type="time" id="thu_end" name="thu_end"> <br>

<b>Friday</b> <br>
<label for="fri_start">start-time</label>
<input type="time" id="fri_start" name="fri_start" onchange="setFricoach()"> 
<label for="fri_end">end-time</label>
<input type="time" id="fri_end" name="fri_end"> <br>

<b>Saturday</b> <br>
<label for="sat_start">start-time</label>
<input type="time" id="sat_start" name="sat_start" onchange="setSatcoach()"> 
<label for="sat_end">end-time</label>
<input type="time" id="sat_end" name="sat_end"> <br>

<input type="submit" value="sign up">
</div>
</form>

<!--this is for the player form-->
<form id="player-form" action="newplayeraccount.pro.php" onsubmit="return validateplayerform()" method="post">
<div class="signup-forms">
 <h3>Player</h3>
<!--username field-->
 <label for="username">Username:</label><br>
 <input type="text" id="username" name="username"><br>
<!--password field-->
 <label for="password">Password:</label><br>
 <input id="playerpassword" type="password" name="password"><br>
<!--confirm password field-->
 <label for="confirmpassword">Confirm Password:</label><br>
 <input id="playerconfirm" type="password"  name="confirmpassword"><br>
 <input type="checkbox" onclick="toggleplayerpassword()">Show Password<br>
<!--region field-->
 <label for="region">Region:</label><br>
 <select id="region" name="region">
        <option value="" selected disabled hidden>Select Region</option>
        <?php
        $resultregion->data_seek(0);
        if ($resultregion ->num_rows > 0) { 
                while ($rowregion = $resultregion ->fetch_assoc()) {
                     echo "<option value=" . $rowregion['region_name'] . " title='" . $rowregion['region_full_name'] . "' >" . $rowregion['region_name'] . "</option>";       
                }
                echo "</select>" . "<br>";
        }
        ?>

<!--this is for linking to a region page-->
<span>
<a href="regionpage.php">What server am i in?</a><br>
</span>
</div>
<!--timetable form-->
<div class="timetable-form">
<b>Timetable</b> <br>
<label for="timezone">Timezone:</label>
<select id="timezone" name="timezone">
        <option value="" selected disabled hidden>Select timezone</option>
        <?php
        $resulttimezone->data_seek(0);
        if ($resulttimezone ->num_rows > 0) {        
                while ($rowzone = $resulttimezone ->fetch_assoc()) {
                        if ($rowzone['timezone_name'] === $currenttimezone){
                        echo "<option value=" . $rowzone['timezone_id'] . " selected>" . $rowzone['timezone_name'] . "</option>";  
                        }
                else {
                     echo "<option value=" . $rowzone['timezone_id'] . " >" . $rowzone['timezone_name'] . "</option>";   
                }
                
        }
        echo "</select>" . "<br>";
        }
?>

<b>Sunday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="sun_start" name="sun_start"> 
<label for="sun_end">end-time</label> 
<input type="time" id="sun_end" name="sun_end"> <br>

<b>Monday</b> <br>
<label for="mon_start">start-time</label>
<input type="time" id="mon_start" name="mon_start">
<label for="mon_end">end-time</label> 
<input type="time" id="mon_end" name="mon_end"><br>

<b>Tuesday</b> <br>
<label for="tue_start">start-time</label>
<input type="time" id="tue_start" name="tue_start">
<label for="tue_end">end-time</label> 
<input type="time" id="tue_end" name="tue_end"> <br>

<b>Wendesday</b> <br>
<label for="wed_start">start-time</label>
<input type="time" id="wed_start" name="wed_start"> 
<label for="wed_end">end-time</label>
<input type="time" id="wed_end" name="wed_end"> <br>

<b>Thursday</b> <br>
<label for="thu_start">start-time</label>
<input type="time" id="thu_start" name="thu_start"> 
<label for="thu_end">end-time</label>
<input type="time" id="thu_end" name="thu_end"> <br>

<b>Friday</b> <br>
<label for="fri_start">start-time</label>
<input type="time" id="fri_start" name="fri_start"> 
<label for="fri_end">end-time</label>
<input type="time" id="fri_end" name="fri_end"> <br>

<b>Saturday</b> <br>
<label for="sat_start">start-time</label>
<input type="time" id="sat_start" name="sat_start"> 
<label for="sat_start">end-time</label>
<input type="time" id="sat_end" name="sat_end"> <br>

<!--submit button-->
<input type="submit" value="sign up">
</div>
</form>
<!--this is for error messages if the validation fails-->
<a id="errormsg"></a>
<div id="signup-forms">

<!--this is for error messages if the validation succeed-->
<?php
if (isset($_SESSION["loginerr"]) != ""){
        echo $_SESSION["loginerr"];
    }
?>

<script>
//this function shows the coach form
function showcoach() {
        document.getElementById("coach-form").style.display="block";
        document.getElementById("player-form").style.display="none";
        var errormsg = document.getElementById('errormsg');
        errormsg.innerHTML="";
}
//this function shows the player form
function showplayer() {
        document.getElementById("coach-form").style.display="none";
        document.getElementById("player-form").style.display="block";
        var errormsg = document.getElementById('errormsg');
        errormsg.innerHTML="";
}
//this function validates the coach form
function validatecoachform() {
        var username = document.forms["coach-form"]["username"].value;
        var password = document.forms["coach-form"]["password"].value;
        var passwordcom = document.forms["coach-form"]["confirmpassword"].value;
        var region = document.forms["coach-form"]["region"].value;
        var description = document.forms["coach-form"]["description"].value;
        var games = document.forms["coach-form"]["games"].value;

        var timezone = document.forms["coach-form"]["timezone"].value;
        var sunstart = document.forms["coach-form"]["sun_start"].value;
        var sunend = document.forms["coach-form"]["sun_end"].value;
        var monstart = document.forms["coach-form"]["mon_start"].value;
        var monend = document.forms["coach-form"]["mon_end"].value;
        var tuestart = document.forms["coach-form"]["tue_start"].value;
        var tueend = document.forms["coach-form"]["tue_end"].value;
        var wedstart = document.forms["coach-form"]["wed_start"].value;
        var wedend = document.forms["coach-form"]["wed_end"].value;
        var thurstart = document.forms["coach-form"]["thu_start"].value;
        var thurend = document.forms["coach-form"]["thu_end"].value;
        var fristart = document.forms["coach-form"]["fri_start"].value;
        var friend = document.forms["coach-form"]["fri_end"].value;
        var satstart = document.forms["coach-form"]["sat_start"].value;
        var satend = document.forms["coach-form"]["sat_end"].value;

        //checks if username is blank
        if (username == "") {
                errormsg.innerHTML="Username must be filled out";
                return false;
        }
        //checks if password is blank
        if (password == "") {
                errormsg.innerHTML="Password must be filled out";
                return false;
        }
        //checks if both passwords are the same
        if (password != passwordcom) {
                errormsg.innerHTML="Both passwords must match";
                return false;
        }
        //checks if region is blank
        if (region == "") {
                errormsg.innerHTML="Region must be selected";
                return false;
        }
        //checks if description is blank
        if (description == ""){
                errormsg.innerHTML="Description must be filled";
                return false;
        }
        //checks if game is blank
        if (games == ""){
                errormsg.innerHTML="Game must be selected";
                return false;
        }
        if (timezone == ""){
                errormsg.innerHTML="Timezone must be selected";
                return false;
        }

        if (sunstart == "" || sunend == "" || monstart == "" || monend == "" || tuestart == "" || tueend == "" || wedstart == "" || wedend == ""
        || thurstart == "" || thurend == "" || fristart == "" || friend == "" || satstart == "" || satend == "") {
                errormsg.innerHTML="All time slots must be filled";
                return false;
        }

}
function validateplayerform() {
        var username = document.forms["player-form"]["username"].value;
        var password = document.forms["player-form"]["password"].value;
        var passwordcom = document.forms["player-form"]["confirmpassword"].value;
        var region = document.forms["player-form"]["region"].value;

        var timezone = document.forms["player-form"]["timezone"].value;
        var sunstart = document.forms["player-form"]["sun_start"].value;
        var sunend = document.forms["player-form"]["sun_end"].value;
        var monstart = document.forms["player-form"]["mon_start"].value;
        var monend = document.forms["player-form"]["mon_end"].value;
        var tuestart = document.forms["player-form"]["tue_start"].value;
        var tueend = document.forms["player-form"]["tue_end"].value;
        var wedstart = document.forms["player-form"]["wed_start"].value;
        var wedend = document.forms["player-form"]["wed_end"].value;
        var thurstart = document.forms["player-form"]["thu_start"].value;
        var thurend = document.forms["player-form"]["thu_end"].value;
        var fristart = document.forms["player-form"]["fri_start"].value;
        var friend = document.forms["player-form"]["fri_end"].value;
        var satstart = document.forms["player-form"]["sat_start"].value;
        var satend = document.forms["player-form"]["sat_end"].value;

        //checks if username is blank
        if (username == "") {
                errormsg.innerHTML="Username must be filled out";
                return false;
        }
        //checks if password is blank
        if (password == "") {
                errormsg.innerHTML="Password must be filled out";
                return false;
        }
        //checks if passwords match
        if (password != passwordcom) {
                errormsg.innerHTML="Passwords must match";
                return false;
        }
        //checks if region is blank
        if (region == "") {
                errormsg.innerHTML="Region must be selected";
                return false;
        }

        if (timezone == ""){
                errormsg.innerHTML="Timezone must be selected";
                return false;
        }

        if (sunstart == "" || sunend == "" || monstart == "" || monend == "" || tuestart == "" || tueend == "" || wedstart == "" || wedend == ""
        || thurstart == "" || thurend == "" || fristart == "" || friend == "" || satstart == "" || satend == "") {
                errormsg.innerHTML="All time slots must be filled";
                return false;
        }
}
//this toggles the visibity of the passwords
function togglecoachpassword(){
        var toggle = document.getElementById("coachpassword");
        var toggle2 = document.getElementById("coachconfirm");
        if (toggle.type === "password"){
                toggle.type = "text";
                toggle2.type = "text";
        } else {
                toggle.type = "password";
                toggle2.type = "password";
        }

}
//this toggles the visibity of the passwords
function toggleplayerpassword(){
        var toggle = document.getElementById("playerpassword");
        var toggle2 = document.getElementById("playerconfirm");
        if (toggle.type === "password"){
                toggle.type = "text";
                toggle2.type = "text";
        } else {
                toggle.type = "password";
                toggle2.type = "password";
        }

}

function setSuncoach(){
        var start = document.forms["coach-form"]["sun_start"];
        var end = document.forms["coach-form"]["sun_end"];

        var min = start.value;

        end.setAttribute("min", min);
}

function setMoncoach(){
        var start = document.forms["coach-form"]["mon_start"];
        var end = document.forms["coach-form"]["mon_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setTuecoach(){
        var start = document.forms["coach-form"]["tue_start"];
        var end = document.forms["coach-form"]["tue_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setWedcoach(){
        var start = document.forms["coach-form"]["wed_start"];
        var end = document.forms["coach-form"]["wed_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setThucoach(){
        var start = document.forms["coach-form"]["thu_start"];
        var end = document.forms["coach-form"]["thu_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setFricoach(){
        var start = document.forms["coach-form"]["fri_start"];
        var end = document.forms["coach-form"]["fri_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setSatcoach(){
        var start = document.forms["coach-form"]["sat_start"];
        var end = document.forms["coach-form"]["sat_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setSunplayer(){
        var start = document.forms["player-form"]["sun_start"];
        var end = document.forms["player-form"]["sun_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setMonplayer(){
        var start = document.forms["player-form"]["mon_start"];
        var end = document.forms["player-form"]["mon_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setTueplayer(){
        var start = document.forms["player-form"]["tue_start"];
        var end = document.forms["player-form"]["tue_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setWedplayer(){
        var start = document.forms["player-form"]["wed_start"];
        var end = document.forms["player-form"]["wed_end"];
        var min = start.value;

        end.setAttribute("min", min);
}
function setThuplayer(){
        var start = document.forms["player-form"]["thu_start"];
        var end = document.forms["player-form"]["thu_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setFriplayer(){
        var start = document.forms["player-form"]["fri_start"];
        var end = document.forms["player-form"]["fri_end"];

        var min = start.value;

        end.setAttribute("min", min);
}
function setSatplayer(){
        var start = document.forms["player-form"]["sat_start"];
        var end = document.forms["player-form"]["sat_end"];

        var min = start.value;

        end.setAttribute("min", min);
}

</script>

<script>
showcoach();
</script>

</html>