<!DOCTYPE html>

<title>Profile page</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="UTF-8">
</head>
 

<?php
require "config.php";
include "header.php";

$notloggedin= "";
$loggedin= "";

//checks if a user is signed in
if (isset($_SESSION["username"]) != ""){
    //checks if a coach or a player is signed in
    if($_SESSION["type"] == "coach"){
            //echo $_SESSION["type"];
            //echo "this is a coach";
            $notloggedin = "style='display:none;'";
            $loggedin = "style='display:none;'";
    }
    else if ($_SESSION["type"] == "player"){
            //echo "this is a player";
            $notloggedin = "style='display:none;'";
    }
       
}
else {
  //echo "noone is logged in";
  $loggedin = "style='display:none;'";
}

$username = $_POST['username'];

$searchcoach = "SELECT * FROM ((coach 
INNER JOIN region ON coach.region_id = region.region_id)
INNER JOIN games ON coach.games_id = games.games_id)";
$resultcoach = $conn->query($searchcoach);


echo "<h1>" . $username . "'s Profile" . "</h1>";
//echo $username;

if ($resultcoach ->num_rows > 0) {  
        //this is searching for the correct coach id and pasting their data
          while($row = $resultcoach->fetch_assoc()) {
                if ($username === $row['username']){
                echo "<a>Username: " . $row['username'] . "<br>" .
                "<a>Region: " . $row['region_name'] . "<br>" .
                "<a>Game: " . $row['games_name'] . "<br>" .
                "<a>Description: " . $row['description'] . "<br>" .
                "<a>Price: &pound; " . $row['payment_price'] . "<br>" .
                "<a>Rating: " . $row['rating'] . "<br>";
                break;
                } 
                else {
                        //echo "skipped username";
                }
        }
}


$searchtimetable = "SELECT * from ((timetable
INNER JOIN timezone ON timetable.timezone_id = timezone.timezone_id)
INNER JOIN coach ON timetable.coach_id = coach.coach_id)
WHERE username = '$username'";

$resulttimetable = $conn->query($searchtimetable);

if ($resulttimetable ->num_rows > 0) {
        while ($rowtable = $resulttimetable->fetch_assoc()) {
                //setting all the times to variables
                $sundaystart = date('H:i' , strtotime($rowtable['sunday_start_time']));
                $sundayend = date('H:i' , strtotime($rowtable['sunday_end_time']));
                $mondaystart = date('H:i' , strtotime($rowtable['monday_start_time']));
                $mondayend = date('H:i' , strtotime($rowtable['monday_end_time']));
                $tuesdaystart = date('H:i' , strtotime($rowtable['tuesday_start_time']));
                $tuesdayend = date('H:i' , strtotime($rowtable['tuesday_end_time']));
                $wednesdaystart = date('H:i' , strtotime($rowtable['wednesday_start_time']));
                $wednesdayend = date('H:i' , strtotime($rowtable['wednesday_end_time']));
                $thursdaystart = date('H:i' , strtotime($rowtable['thursday_start_time']));
                $thursdayend = date('H:i' , strtotime($rowtable['thursday_end_time']));
                $fridaystart = date('H:i' , strtotime($rowtable['friday_start_time']));
                $fridayend = date('H:i' , strtotime($rowtable['friday_end_time']));
                $saturdaystart = date('H:i' , strtotime($rowtable['saturday_start_time']));
                $saturdayend = date('H:i' , strtotime($rowtable['saturday_end_time']));

                $timezone = $rowtable['timezone_name'];

                echo "<h4>Schedule</h4>" . 
                "Timezone: " . $timezone . "<br>" .
                "Sunday: " . $sundaystart . "-" . $sundayend . "<br>" . 
                "Monday: " . $mondaystart . "-" . $mondayend . "<br>" . 
                "Tuesday: " . $tuesdaystart . "-" . $tuesdayend . "<br>" .
                "Wednesday: " . $wednesdaystart  . "-" . $wednesdayend . "<br>" .
                "Thursday: " . $thursdaystart . "-" . $thursdayend . "<br>" .
                "Friday: " . $fridaystart . "-" . $fridayend . "<br>" .
                "Saturday: " . $saturdaystart . "-" . $saturdayend . "<br>";

        } 
}
?>

<form id="booking" action="bookingpage.php" method="post">
<input name="player" type="hidden" value = "<?php echo $_SESSION["username"]; ?>"></input>
<input name="coach" type="hidden" value = "<?php echo $username; ?>" ></input>

<input type="submit" value="book a session" <?php echo $loggedin; ?>></input>

</form>

<input type="button" value="sign in to book a session" onclick="location.href='loginpage.php';" <?php echo $notloggedin; ?>></input>
<script>

</script>


</html>