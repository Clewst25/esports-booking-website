<!DOCTYPE html>

<title>Profile page</title>
        <meta charset="UTF-8">
</head>

<?php
require "config.php";
include "header.php";

//sessions
$username = $_SESSION['username'];
$type = $_SESSION["type"];
$id = $_SESSION["id"];

//this checks which type of user it is for the timetable
if ($type === "coach") {
        $filter = "WHERE coach_id = '$id'";
}

if ($type === "player") {
        $filter = "WHERE player_id = '$id'";
}

//select queries
$searchcoach = "SELECT * FROM ((coach 
INNER JOIN region on coach.region_id = region.region_id)
INNER JOIN games on coach.games_id = games.games_id)
$filter";

$searchplayer = "SELECT * FROM player 
INNER JOIN region on player.region_id = region.region_id
$filter";

$searchregion = "SELECT * FROM region";
$searchgame = "SELECT * FROM games";
$searchtimezone = "SELECT * FROM timezone";
$searchtimetable = "SELECT * from timetable 
INNER JOIN timezone ON timetable.timezone_id = timezone.timezone_id $filter";

//
$resultcoach = $conn->query($searchcoach);
$resultplayer = $conn->query($searchplayer);
$resultregion = $conn->query($searchregion);
$resultgame = $conn->query($searchgame);
$resulttimezone = $conn->query($searchtimezone);
$resulttimetable = $conn->query($searchtimetable);

if ($resulttimetable ->num_rows > 0) {
        while ($rowtable = $resulttimetable->fetch_assoc()) {
                //setting all the times to variables
                $sundaystart = $rowtable['sunday_start_time'];
                $sundayend = $rowtable['sunday_end_time'];
                $mondaystart = $rowtable['monday_start_time'];
                $mondayend = $rowtable['monday_end_time'];
                $tuesdaystart = $rowtable['tuesday_start_time'];
                $tuesdayend = $rowtable['tuesday_end_time'];
                $wednesdaystart = $rowtable['wednesday_start_time'];
                $wednesdayend = $rowtable['wednesday_end_time'];
                $thursdaystart = $rowtable['thursday_start_time'];
                $thursdayend = $rowtable['thursday_end_time'];
                $fridaystart = $rowtable['friday_start_time'];
                $fridayend = $rowtable['friday_end_time'];
                $saturdaystart = $rowtable['saturday_start_time'];
                $saturdayend = $rowtable['saturday_end_time'];
                $currenttimezone = $rowtable['timezone_name'];
        } 
}

//echo $id;

//this is if the type is coach
if ($type == "coach") {
        echo "Coach Account" . "<br>";
        if ($resultcoach ->num_rows > 0) {  
        //this is searching for the correct coach id and pasting their data
          while($rowcoach = $resultcoach->fetch_assoc()) {
                if ($username === $rowcoach['username']){
                $currentregioncoach = $rowcoach['region_name'];
                $currentgame = $rowcoach['games_name'];
                break;
                } 
                else {
                }
                }
        }
//this is if the user is a player
} else if ($type == "player") {
        echo "Player Account" . "<br>";
        if ($resultplayer ->num_rows > 0) {  
                //this is searching for the correct player id and pasting their data
                  while($rowplayer = $resultplayer->fetch_assoc()) {
                        if ($username === $rowplayer['username']){
                        $currentregionplayer = $rowplayer['region_name'];
                        break;
                        } 
                        else {
                        }
                        }
                }
}

?>

<h1><?php echo $username ?>'s Profile</h1>

<!--this is the coach edit form-->

<form id="coach-form" action="updatecoachaccount.pro.php" method="post">

<label for="regioncoach">Region:</label><br>
<select id="regioncoach" name="regioncoach">
<?php
$resultregion->data_seek(0);
if ($resultregion ->num_rows > 0) { 
        while ($rowregion = $resultregion ->fetch_assoc()) {
                if ($rowregion['region_name'] === $currentregioncoach){
                        echo "<option value=" . $rowregion['region_name'] . " title='" . $rowregion['region_full_name'] . "' selected>" . $rowregion['region_name'] . "</option>";  
                }
                else {
                     echo "<option value=" . $rowregion['region_name'] . " title='" . $rowregion['region_full_name'] . "' >" . $rowregion['region_name'] . "</option>";   
                }       
        }
        echo "</select>" . "<br>";
}
?>

</select>

<span>
    <a href="regionpage.php">What server am i in?</a><br>
</span>

<label for="description">Description:</label><br>
<textarea name="description" rows="5" cols="40"> <?php echo $rowcoach['description'] ?> </textarea><br>

<label for="gamescoach">Game of choice: </label><br>
<select id="gamescoach" name="gamescoach">
<?php
$resultgame->data_seek(0);
if ($resultgame ->num_rows > 0) { 
        while ($rowgame = $resultgame ->fetch_assoc()) {
                if ($rowgame['games_name'] === $currentgame){
                        echo "<option value=" . $rowgame['games_name'] . " title= '" . $rowgame['games_full_name'] . "' selected>" . $rowgame['games_name'] . "</option>";  
                }
                else {
                     echo "<option value=" . $rowgame['games_name'] . " title= '" . $rowgame['games_full_name'] . "' >" . $rowgame['games_name'] . "</option>";   
                }       
        }
        echo "</select>" . "<br>";
}    

?>

</select><br>

<input type="submit" value="Save details">

</form>


<!--this is the player edit form-->

<form id="player-form" action="updateplayeraccount.pro.php"  method="post">

<label for="regionplayer">Region:</label><br>
<select id="regionplayer" name="regionplayer">
<?php
$resultregion->data_seek(0);
if ($resultregion ->num_rows > 0) { 
        while ($rowregion = $resultregion ->fetch_assoc()) {
                if ($rowregion['region_name'] === $currentregionplayer){
                        echo "<option value=" . $rowregion['region_name'] . " title='" . $rowregion['region_full_name'] . "' selected>" . $rowregion['region_name'] . "</option>";  
                }
                else {
                     echo "<option value=" . $rowregion['region_name'] . " title='" . $rowregion['region_full_name'] . "' >" . $rowregion['region_name'] . "</option>";   
                }       
        }
        echo "</select>" . "<br>";
}
?>

<span>
    <a href="regionpage.php">What server am i in?</a><br>
</span>

<input type="submit" value="save details">
</form>

<form id="timetable" action="updatetimetable.pro.php" method="post">

<h3>Edit timetable</h3>

<label for="timezoneselect">Timezone: </label>
<select id="timezoneselect" name="timezoneselect">
<?php
if ($resulttimezone ->num_rows > 0) {        
        while ($rowzone = $resulttimezone ->fetch_assoc()) {
                if ($rowzone['timezone_name'] === $currenttimezone){
                        echo "<option value=" . $rowzone['timezone_offset'] . " selected>" . $rowzone['timezone_name'] . "</option>";  
                }
                else {
                     echo "<option value=" . $rowzone['timezone_offset'] . " >" . $rowzone['timezone_name'] . "</option>";   
                }
                
        }
        echo "</select>" . "<br>";
}
?>

<b>Sunday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="sun_start" name="sun_start" value=<?php echo $sundaystart ?>> 
<label for="sun_end">end-time</label> 
<input type="time" id="sun_end" name="sun_end" value=<?php echo $sundayend ?>> <br>

<b>Monday</b> <br>
<label for="mon_start">start-time</label>
<input type="time" id="mon_start" name="mon_start" value=<?php echo $mondaystart ?>>
<label for="mon_end">end-time</label> 
<input type="time" id="mon_end" name="mon_end" value=<?php echo $mondayend ?>><br>

<b>Tuesday</b> <br>
<label for="tue_start">start-time</label>
<input type="time" id="tue_start" name="tue_start" value=<?php echo $tuesdaystart ?>>
<label for="tue_end">end-time</label> 
<input type="time" id="tue_end" name="tue_end" value=<?php echo $tuesdayend ?>> <br>

<b>Wendesday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="wen_start" name="wed_start" value=<?php echo $wednesdaystart ?>> 
<label for="sun_start">end-time</label>
<input type="time" id="wen_end" name="wed_end" value=<?php echo $wednesdayend ?>> <br>

<b>Thursday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="thu_start" name="thu_start" value=<?php echo $thursdaystart ?>> 
<label for="sun_start">end-time</label>
<input type="time" id="thu_end" name="thu_end" value=<?php echo $thursdayend ?>> <br>

<b>Friday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="fri_start" name="fri_start" value=<?php echo $fridaystart ?>> 
<label for="sun_start">end-time</label>
<input type="time" id="fri_end" name="fri_end" value=<?php echo $fridayend ?>> <br>

<b>Saturday</b> <br>
<label for="sun_start">start-time</label>
<input type="time" id="sat_start" name="sat_start" value=<?php echo $saturdaystart ?>> 
<label for="sun_start">end-time</label>
<input type="time" id="sat_end" name="sat_end" value=<?php echo $saturdayend ?>> <br>

<input type="submit" value="Update timetable">
</form>


<a id="testing"></a>

<script>
//this is for showing the coach or player forms depending on the type of user
function showcoach() {
        document.getElementById("coach-form").style.display="block";
        document.getElementById("player-form").style.display="none";
}
function showplayer() {
        document.getElementById("coach-form").style.display="none";
        document.getElementById("player-form").style.display="block";
}
</script>


<script>
var usertype = "<?php echo $type; ?>";
if (usertype == "coach") {
     showcoach();
} else if (usertype == "player") {
     showplayer();
}
</script>

<script>
//this is selecting the current game for the coach
var currentgame = "<?php echo $currentgame ?>";
var selectgame = document.getElementById('gamescoach');

for (var i, j = 0; i= selectgame.options[j]; j++) {
        if(i.value == currentgame) {
                selectgame.selectedIndex = j;
                break;
        }
}
</script>
<script>
//this is selecting the current region for the player
var currentregionplayer = "<?php echo $currentregionplayer ?>";
var selectregionplayer = document.getElementById('regionplayer');

for (var i, j = 0; i= selectregionplayer.options[j]; j++) {
        if(i.value == currentregionplayer) {
                selectregionplayer.selectedIndex = j;
                break;
        }
}
</script>

</html>