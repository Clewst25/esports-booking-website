<?php
require "config.php";
include "header.php";

$username = $_SESSION['username'];
$type = $_SESSION["type"];
$id = $_SESSION["id"];

if(isset($_POST['regionplayer'])){
    $newregion = $_POST['regionplayer'];
} else {
    $newregion = "Name not set in post method";
}


$searchplayer = "SELECT * FROM player WHERE player_id = $id";
$searchregion = "SELECT * FROM region";
$searchgame = "SELECT * FROM games";
$resultplayer = $conn->query($searchplayer);
$resultregion = $conn->query($searchregion);
$resultgame = $conn->query($searchgame);


while($rowregion = $resultregion->fetch_assoc()){
        if ($rowregion["region_name"] === $newregion){
                $region = $rowregion["region_id"];
                //echo $region;
                break;
        }
        else {
        }
}

while($rowgame = $resultgame->fetch_assoc()){
        if ($rowgame["games_name"] === $newgame){
          $game = $rowgame["games_id"];
          //echo $game;
          break;
        }
        else {
        }
      }

$updateplayer = "UPDATE player 
SET region_id = '$region'
WHERE player_id = '$id' ";


if ($conn->query($updateplayer) === TRUE) {
        header("Location: personalpage.php");
        exit();
      } else {
        header("Location: editpage.php");
      }

$conn->close();
?>