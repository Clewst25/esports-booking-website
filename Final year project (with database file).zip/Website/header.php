<?php

if (session_id() == '') {
  session_start();
  }

$loginstyle= "";
$logoutstyle= "";

if (isset($_SESSION["username"]) != ""){
    //echo $_SESSION["type"] . " " . $_SESSION["username"] . " is logged in";
    $loginstyle = "style='display:none;'";
}

else {
  //echo "noone is logged in";
  $logoutstyle = "style='display:none;'";
}

?>
<!DOCTYPE html>
  <head>
    <meta chartset="utf-8">
    <meta name="description" content="this is an example of a meta description. this will often show up in search results.">
    <title>Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <script src="https://kit.fontawesome.com/873b52ab38.js" crossorigin="anonymous"></script>

  </head>
  <body>

  <header>
        <!--this is for the grid layout-->
        <!--this area is for the page links and the search bar-->
        <nav class="page-link-area">
            <!--this is the logo for the website-->
            <img id="logo-img" src="Pictures/Coach4u logo.png">
            <!--these are for the page buttons-->
            <a id="homepage-link" class="page-links" href="index.php">Home</a>            
            <a id="login-link" class="page-links" href="loginpage.php" <?php echo $loginstyle; ?>>login/signup</a>
            <a id="profile-link" class="page-links" href="personalpage.php" <?php echo $logoutstyle; ?>><?php echo $_SESSION["username"] . "'s profile" ?></a>
            <a id="logout-link" class="page-links"  href="logout.pro.php" <?php echo $logoutstyle; ?>>logout</a>
            <!--this is for the searchbar-->
            <span class="searchbar-area">
            <form id="search" action="searchpage.php" method="get">
            <input id="searchbar" name="searchbar" class="searchbar" placeholder="Search.."></input>
            </form>
            </span>    
            <!--<a id="searchpage-link" class="page-links" href="Searchpage.php">Search</a>-->
        </nav>
  </header>

  </html>