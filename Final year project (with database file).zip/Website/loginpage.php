<!DOCTYPE html>
<?php
require "config.php";
include "header.php";
?>
<head>
        <title>Login page</title>
</head>

<body>

<div class="login-forms">
<h1>Login</h1>
<!--this is to switch between coach and player-->
<button id= "coach-button" onclick="showcoach()">Coach</button>
<button id= "player-button" onclick="showplayer()">Player</button>

<!--this is the coach login form-->
<form id="coach-form" action="logincoachaccount.pro.php" onsubmit="return validatecoachform()" method="post">
  <h3>Coach</h3>
<!--username field-->
<label for="username">Username:</label><br>
<input type="text" id="username" name="username"><br>
<!--password field-->
<label for="password">Password:</label><br>
<input id="passwordcoach" type="password" name="password"><br>
<input type="checkbox" onclick="togglecoachpassword()">Show Password<br>

<input type="submit" value="Log in">

<a href="signuppage.php"> No account? sign up here</a>

</form>
<!--this is the player login form-->
<form id="player-form" action="loginplayeraccount.pro.php" onsubmit="return validateplayerform()" method="post">
   <h3>Player</h3>
<!--username field-->
<label for="username">Username:</label><br>
<input id="username" type="text" id="username" name="username"><br>
<!--password field-->
<label for="password">Password:</label><br>
<input id="passwordplayer" type="password" name="password"><br>
<input type="checkbox" onclick="toggleplayerpassword()">Show Password<br>

<input type="submit" value="Log in">

<a href="signuppage.php"> No account? sign up here</a>

</form>

<br>
<!--this is for error messages if the validation fails-->
<a id="errormsg"></a>

<!--this is for error messages if the validation succeed-->
<?php
if (isset($_SESSION["loginerr"]) != ""){
        echo $_SESSION["loginerr"];
    }
?>

<script>
//this function shows the coach form

var coachbtn = document.getElementById("coach-button");
var playerbtn = document.getElementById("player-button");

function showcoach() {
        document.getElementById("coach-form").style.display="block";
        document.getElementById("player-form").style.display="none";
        var errormsg = document.getElementById('errormsg');
        errormsg.innerHTML="";
        coachbtn.style.borderColor = "black";
        coachbtn.style.backgroundColor = "#618685";
        playerbtn.style.borderColor = "grey";
        playerbtn.style.backgroundColor = "lightblue";

}
//this function shows the player form
function showplayer() {
        document.getElementById("coach-form").style.display="none";
        document.getElementById("player-form").style.display="block";
        var errormsg = document.getElementById('errormsg');
        errormsg.innerHTML="";
        playerbtn.style.borderColor = "black";
        playerbtn.style.backgroundColor = "#618685";
        coachbtn.style.borderColor = "grey";
        coachbtn.style.backgroundColor = "lightblue";


}
//this function validates the coach form
function validatecoachform() {
        var username = document.forms["coach-form"]["username"].value;
        var password = document.forms["coach-form"]["password"].value;
        var errormsg = document.getElementById('errormsg');
        if (username == "") {
                errormsg.innerHTML="Username must be filled out";
                return false;
        }
        if (password == "") {
                errormsg.innerHTML="Password must be filled out";
                return false;
        }
}
//this function validates the player form
function validateplayerform() {
        var username = document.forms["player-form"]["username"].value;
        var password = document.forms["player-form"]["password"].value;
        var errormsg = document.getElementById('errormsg');
        if (username == "") {
                errormsg.innerHTML="Username must be filled out";
                //alert("username must be filled out");
                return false;
        }
        if (password == "") {
                errormsg.innerHTML="Password must be filled out";
                //alert("password must be filled out");
                return false;
        }
}
//this function toggles the filter on the coach password box
function togglecoachpassword() {
        var toggle = document.getElementById("passwordcoach");
        if (toggle.type === "password"){
                toggle.type = "text";
        } else {
                toggle.type = "password";
        }
}
//this function toggles the filter on the player password box
function toggleplayerpassword() {
        var toggle = document.getElementById("passwordplayer");
        if (toggle.type === "password"){
                toggle.type = "text";
        } else {
                toggle.type = "password";
        }
}
</script>

<script>
showcoach();
</script>
</div>
</body>

</html>