<!DOCTYPE html>
<?php
require "config.php";
include "header.php";
?>

<head>
        <title>my php page</title>

</head>

<main>
<body>

  <p> Welcome to coach4u, coaching for all! </p>

</body>
</main>

<?php
//include "footer.php";
?>
</html>