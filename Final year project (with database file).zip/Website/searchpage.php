<!DOCTYPE html>

<title>Search results</title>

<?php
require "config.php";
include "header.php";

if (isset($_SESSION["username"]) != ""){
  $loggedplayer = $_SESSION["username"]; 

  $searchplayer = "SELECT * FROM player
  INNER JOIN region on player.region_id = region.region_id
  WHERE username = '$loggedplayer'";
  $resultplayer = $conn->query($searchplayer);

  while($rowplayer = $resultplayer->fetch_assoc()){
    $playerregion = $rowplayer['region_name'];
  }
}

if (isset($_SESSION["username"]) != ""){
  $usercheck = "region_name='$playerregion' DESC,";
  $secondcheck = "";
}
else {
  $usercheck = "";
  $secondcheck = "";
}


if (isset($_GET['searchbar'])) {
    $search = mysqli_real_escape_string($conn, $_GET['searchbar']);
    $sql = "SELECT * FROM ((coach 
    INNER JOIN region ON coach.region_id = region.region_id)
    INNER JOIN games ON coach.games_id = games.games_id)
    WHERE username LIKE '%$search%' 
    OR region_name LIKE '%$search%' 
    OR region_full_name LIKE '%$search%' 
    OR games_name LIKE '%$search%'
    OR games_full_name LIKE '%$search%'
    ORDER BY $usercheck rating $secondcheck DESC";

    $result = $conn->query($sql);
    //echo $result;
    //$queryResult = num_rows($result);

    if ($result ->num_rows > 0) {
        echo "found " . $result ->num_rows . " results";
        echo "<table class='search-table'>";
        $tmpCount = 0;
        while($row = $result->fetch_assoc()){
          if ($tmpCount % 3 == 0){
            echo "<tr>";
            
          }
        echo "<th>" . 
          "<div class='username-text'>" . $row['username'] . "</div> <br>" .
          "<div class='region-game-text'>". "Game: " . $row['games_name'] .
          " Region: " . $row['region_name'] . "</div> <br>" .
          "<div class='description-text'>". "Description: " . $row['description'] . "</div><br>";
          
          if ($row['rating'] === NULL){
            echo "Rating: Not Rated <br>";
            ?>

            <span class="star-rating">
            <label for="star1-<?php echo $row['coach_id']; ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star1-<?php echo $row['coach_id']; ?>" name="rating-<?php echo $row['coach_id']; ?>"
            onclick="displayStarValue<?php echo $row['coach_id']; ?>()" value="1" hidden>

            <label for="star2-<?php echo $row['coach_id'] ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star2-<?php echo $row['coach_id'] ?>" name="rating-<?php echo $row['coach_id']; ?>" 
            onclick="displayStarValue<?php echo $row['coach_id'] ?>()" value="2" hidden>

            <label for="star3-<?php echo $row['coach_id'] ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star3-<?php echo $row['coach_id'] ?>" name="rating-<?php echo $row['coach_id'] ?>" 
            onclick="displayStarValue<?php echo $row['coach_id'] ?>()" value="3" hidden>

            <label for="star4-<?php echo $row['coach_id'] ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star4-<?php echo $row['coach_id'] ?>" name="rating-<?php echo $row['coach_id'] ?>" 
            onclick="displayStarValue<?php echo $row['coach_id'] ?>()" value="4" hidden>

            <label for="star5-<?php echo $row['coach_id'] ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star5-<?php echo $row['coach_id'] ?>" name="rating-<?php echo $row['coach_id'] ?>" 
            onclick="displayStarValue<?php echo $row['coach_id'] ?>()" value="5" hidden>
            </span>
            <br>
            
            <?php
          }
          else {
            echo "Rating: " . $row['rating'] . "<br>";
            ?>

            <span class="star-rating">
            <label for="star1-<?php echo $row['coach_id']; ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star1-<?php echo $row['coach_id']; ?>" name="rating-<?php echo $row['coach_id']; ?>"
            onclick="displayStarValue<?php echo $row['coach_id']; ?>()" value="1" hidden>

            <label for="star2-<?php echo $row['coach_id']; ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star2-<?php echo $row['coach_id']; ?>" name="rating-<?php echo $row['coach_id']; ?>"
            onclick="displayStarValue<?php echo $row['coach_id']; ?>()" value="2" hidden>

            <label for="star3-<?php echo $row['coach_id']; ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star3-<?php echo $row['coach_id']; ?>" name="rating-<?php echo $row['coach_id']; ?>"
            onclick="displayStarValue<?php echo $row['coach_id']; ?>()" value="3" hidden>

            <label for="star4-<?php echo $row['coach_id']; ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star4-<?php echo $row['coach_id']; ?>" name="rating-<?php echo $row['coach_id']; ?>"
            onclick="displayStarValue<?php echo $row['coach_id']; ?>()" value="4" hidden>

            <label for="star5-<?php echo $row['coach_id']; ?>"><i class="fa fa-star"></i></label>
            <input type="radio" id="star5-<?php echo $row['coach_id']; ?>" name="rating-<?php echo $row['coach_id']; ?>"
            onclick="displayStarValue<?php echo $row['coach_id']; ?>()" value="5" hidden>

            </span>
            <br>
            <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
            
            <script>
            //assigns labels to their inputs
            var labels = document.getElementsByTagName('LABEL');
              for (var i=0; i < labels.length; i++) {
                if (labels[i].htmlFor != '') {
                        var elem = document.getElementById(labels[i].htmlFor);
                        if (elem)
                        elem.label = labels[i];

                }
              }

            var star1_<?php echo $row['coach_id']; ?> = document.getElementById('star1-<?php echo $row['coach_id']; ?>').label;
            var star2_<?php echo $row['coach_id']; ?> = document.getElementById('star2-<?php echo $row['coach_id']; ?>').label;
            var star3_<?php echo $row['coach_id']; ?> = document.getElementById('star3-<?php echo $row['coach_id']; ?>').label;
            var star4_<?php echo $row['coach_id']; ?> = document.getElementById('star4-<?php echo $row['coach_id']; ?>').label;
            var star5_<?php echo $row['coach_id']; ?> = document.getElementById('star5-<?php echo $row['coach_id']; ?>').label;

            function resetStarColors<?php echo $row['coach_id']; ?>() {
                star1_<?php echo $row['coach_id'] ?>.style.color = 'white';
                star2_<?php echo $row['coach_id'] ?>.style.color = 'white';
                star3_<?php echo $row['coach_id'] ?>.style.color = 'white';
                star4_<?php echo $row['coach_id'] ?>.style.color = 'white';
                star5_<?php echo $row['coach_id'] ?>.style.color = 'white';
            }

            function setStarColors<?php echo $row['coach_id']; ?>() {
            var starvalue = "<?php echo $row['rating']; ?>";

              if (starvalue < 1.5) {
                        resetStarColors<?php echo $row['coach_id']; ?>();
                        star1_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                }
                else if (starvalue < 2.5) {
                        resetStarColors<?php echo $row['coach_id']; ?>();
                        star1_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star2_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                }
                else if (starvalue < 3.5) {
                        resetStarColors<?php echo $row['coach_id']; ?>();
                        star1_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star2_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star3_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                }
                else if (starvalue < 4.5) {
                        resetStarColors<?php echo $row['coach_id']; ?>();
                        star1_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star2_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star3_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star4_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                }
                else if (starvalue <= 5) {
                        resetStarColors<?php echo $row['coach_id']; ?>();
                        star1_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star2_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star3_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star4_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                        star5_<?php echo $row['coach_id']; ?>.style.color = 'yellow';
                }
              }

setStarColors<?php echo $row['coach_id']; ?>();

</script>
            <?php
          }

          $username = $row['username'];
          ?>
          <form action="profilepage.php" method="post">
          <input type="hidden" name="username" value="<?php echo $username; ?>">

          <?php
          echo "<input type='submit' value='Click here to view profile'/>" .
          "</form>" . "</th>";
          
          $tmpCount ++;
        }
    } else {
      echo "There are no results matching your search!";
    }
}

?>

</tr>
</table>

</html>

