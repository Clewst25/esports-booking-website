<?php
require "config.php";
include "header.php";

$datebooked = $_POST["selecteddate"];
$timebooked = $_POST["booking-time"];

$offsetdate = $_POST["global-date"];
$offsettime  = $_POST["global-time"];

$playername = $_POST["playername"];
$coachname = $_POST["coachname"];
$bookingid = $_POST["bookingid"];

echo "Booking number: " . $bookingid . " was changed to " . $datebooked . "-" . $timebooked;

echo "<br>" . $offsetdate . "-" . $offsettime; 

$searchbooking = "SELECT * FROM booking WHERE booking_id = $bookingid";

$resultbooking = $conn->query($searchbooking);

$updatebooking = "UPDATE booking
SET booking_date = '$datebooked',
booking_date_offset = '$offsetdate',
booking_time = '$timebooked',
booking_time_offset = '$offsettime'
WHERE booking_id = '$bookingid' ";

if ($conn->query($updatebooking) === TRUE) {
    header("Location: personalpage.php");
    exit();
} else {
    header("Location: editbooking.php");
}

$conn->close();
?>