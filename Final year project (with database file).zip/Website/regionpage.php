<!DOCTYPE html>
<?php
require "config.php";
include "header.php";
?>
<head>
        <title>my php page</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <!--<img src="Coach4u logo.png" >-->
</head>

<body>
    <a>Each region covers a group of countries <br>
    <a>Below there is a table to show the countries covered by those regions<br>

<table id="Region-table">
<thead>
  <tr>
    <th>Server Countries</th>
    <th>Server Name</th>
    <th>Abbreviation</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td><img src="Pictures/Brazil.png"></td>
    <td>Brazil</td>
    <td>BR</td>
  </tr>
  <tr>
    <td><img src="Pictures/EUNE.png"></td>
    <td>Europe Nordic and east</td>
    <td>EUNE</td>
  </tr>
  <tr>
    <td><img src="Pictures/EUW.png"></td>
    <td>Europe West</td>
    <td>EUW</td>
  </tr>
  <tr>
    <td><img src="Pictures/LAN.png"></td>
    <td>Latin America North</td>
    <td>LAN</td>
  </tr>
  <tr>
    <td><img src="Pictures/LAS.png"></td>
    <td>Latin America South</td>
    <td>LAS</td>
  </tr>
  <tr>
    <td><img src="Pictures/NA.png"></td>
    <td>North America</td>
    <td>NA</td>
  </tr>
  <tr>
    <td><img src="Pictures/OCE.png"></td>
    <td>Oceania</td>
    <td>OCE</td>
  </tr>
  <tr>
    <td><img src="Pictures/RU.png"></td>
    <td>Russia</td>
    <td>RU</td>
  </tr>
  <tr>
    <td><img src="Pictures/TR.png"></td>
    <td>Turkey</td>
    <td>TR</td>
  </tr>
  <tr>
    <td><img src="Pictures/JP.png"></td>
    <td>Japan</td>
    <td>JP</td>
  </tr>
  <tr>
    <td></td>
    <td>Republic of Korea</td>
    <td>KR</td>
  </tr>
</tbody>
</table>
    </table>

<h2>What if my country is not in any server?</h2>

<a>if this is the case then put your server as the one closest to your country</a> 
</body>