<!DOCTYPE html>

<title>Profile page</title>
        <meta charset="UTF-8">
</head>

<?php
require "config.php";
include "header.php";

//session data
$username = $_SESSION['username'];
$type = $_SESSION["type"];
$id = $_SESSION["id"];

//this checks which type of user it is for the timetable
if ($type === "coach") {
        $filter = "WHERE coach_id = '$id'";
        $bookingfilter = "WHERE booking.coach_id = '$id'";
}

if ($type === "player") {
        $filter = "WHERE player_id = '$id'";
        $bookingfilter = "WHERE booking.player_id = '$id'";
}

//search quries
$searchcoach = "SELECT * FROM ((coach 
INNER JOIN region ON coach.region_id = region.region_id)
INNER JOIN games ON coach.games_id = games.games_id)
$filter";
$searchplayer = "SELECT * FROM player 
INNER JOIN region ON player.region_id = region.region_id
$filter";

//run queries
$resultcoach = $conn->query($searchcoach);
$resultplayer = $conn->query($searchplayer);

echo "<h1>" . $username . "'s Profile" . "</h1>" . "<div class='personal-page'>";

if ($type == "coach") {
        echo "<h3>Coach Account</h3>";
        if ($resultcoach ->num_rows > 0) {  
        //this is searching for the correct coach id and pasting their data
          while($rowcoach = $resultcoach->fetch_assoc()) {
                if ($username === $rowcoach['username']){
                echo "<a>Username: " . $rowcoach['username'] . "</a> <br>" .
                "<a>Region: " . $rowcoach['region_name'] . "<br>" .
                "<a>Game: " . $rowcoach['games_name'] . "<br>" .
                "<a>Description: " . $rowcoach['description'] . "<br>" .
                "<a>Price: " . $rowcoach['payment_price'] . "<br>" .
                "<a>Rating: " . $rowcoach['rating'] . "<br>";
                break;
                } 
                else {
                        //echo "skipped username";
                }
                }
        }
} else if ($type == "player") {
        echo "<h3>Player Account</h3><br>";
        if ($resultplayer ->num_rows > 0) {  
                //this is searching for the correct player id and pasting their data
                  while($rowplayer = $resultplayer->fetch_assoc()) {
                        if ($username === $rowplayer['username']){
                        echo "<a>Username: " . $rowplayer['username'] . "<br>" .
                        "<a>Region: " . $rowplayer['region_name'] . "<br>";
                        break;
                        } 
                        else {
                                //echo "skipped username";
                        }
                        }
                }
}


//this is the query for the timetable
$searchtimetable = "SELECT * from timetable
INNER JOIN timezone ON timetable.timezone_id = timezone.timezone_id
$filter";
/*
echo "this is the query " . $searchtimetable . "<br>";
*/
$resulttimetable = $conn->query($searchtimetable);

if ($resulttimetable ->num_rows > 0) {
        while ($rowtable = $resulttimetable->fetch_assoc()) {
                //setting all the times to variables
                $sundaystart = date('H:i' , strtotime($rowtable['sunday_start_time']));
                $sundayend = date('H:i' , strtotime($rowtable['sunday_end_time']));
                $mondaystart = date('H:i' , strtotime($rowtable['monday_start_time']));
                $mondayend = date('H:i' , strtotime($rowtable['monday_end_time']));
                $tuesdaystart = date('H:i' , strtotime($rowtable['tuesday_start_time']));
                $tuesdayend = date('H:i' , strtotime($rowtable['tuesday_end_time']));
                $wednesdaystart = date('H:i' , strtotime($rowtable['wednesday_start_time']));
                $wednesdayend = date('H:i' , strtotime($rowtable['wednesday_end_time']));
                $thursdaystart = date('H:i' , strtotime($rowtable['thursday_start_time']));
                $thursdayend = date('H:i' , strtotime($rowtable['thursday_end_time']));
                $fridaystart = date('H:i' , strtotime($rowtable['friday_start_time']));
                $fridayend = date('H:i' , strtotime($rowtable['friday_end_time']));
                $saturdaystart = date('H:i' , strtotime($rowtable['saturday_start_time']));
                $saturdayend = date('H:i' , strtotime($rowtable['saturday_end_time']));

                $timezone = $rowtable['timezone_name'];

                echo "<h4>Schedule</h4>" . 
                "Timezone: " . $timezone . "<br>" .
                "Sunday: " . $sundaystart . "-" . $sundayend . "<br>" . 
                "Monday: " . $mondaystart . "-" . $mondayend . "<br>" . 
                "Tuesday: " . $tuesdaystart . "-" . $tuesdayend . "<br>" .
                "Wednesday: " . $wednesdaystart  . "-" . $wednesdayend . "<br>" .
                "Thursday: " . $thursdaystart . "-" . $thursdayend . "<br>" .
                "Friday: " . $fridaystart . "-" . $fridayend . "<br>" .
                "Saturday: " . $saturdaystart . "-" . $saturdayend . "<br>" . 
                "<button onclick=" . "location.href='editpage.php';" . ">Edit information</button></div>";

        } 
}

$searchbooking = "SELECT booking_id, booking.player_id, booking.coach_id, booking_date, 
booking_time, booking_date_offset, booking_time_offset, has_paid, is_completed, rating_given, player.username AS playerusername, coach.username AS coachusername
FROM ((booking
INNER JOIN coach ON booking.coach_id = coach.coach_id)
INNER JOIN player ON booking.player_id = player.player_id)
$bookingfilter AND booking.is_completed = 'N'";

$resultbooking = $conn->query($searchbooking);

$searchcompletedbooking = "SELECT booking_id, booking.player_id, booking.coach_id, booking_date,
booking_time, booking_date_offset, booking_time_offset, has_paid, is_completed, rating_given, player.username AS playerusername, coach.username AS coachusername
FROM ((booking
INNER JOIN coach ON booking.coach_id = coach.coach_id)
INNER JOIN player ON booking.player_id = player.player_id)
$bookingfilter AND booking.is_completed = 'Y'";

$resultcompletedbooking = $conn->query($searchcompletedbooking);

echo "<div class='ongoing-booking'><h4> Ongoing Bookings</h4>" ;

if ($resultbooking ->num_rows > 0) {
        while ($rowbooking = $resultbooking->fetch_assoc()) {
                //echo "hello there is a booking" . "<br>";
                if ($type === 'player') {
                        echo "Coach: " . $rowbooking['coachusername'] . "<br>";
                }
                else if ($type === 'coach') {
                        echo "Player: " . $rowbooking['playerusername'] . "<br>";
                }
                if ($type === 'player'){
                        echo "Date: " . $rowbooking['booking_date'] . "<br>" . 
                        "Time: " . $rowbooking['booking_time'] . "<br>";
                }
                
                if ($type === 'coach') {
                        echo "Date: " . $rowbooking['booking_date_offset'] . "<br>" . 
                        "Time: " . $rowbooking['booking_time_offset'] . "<br>";
                }
                
                ?>
                <form action="editbooking.php" method="post">
                <input type="hidden" name="coachusername" value="<?php echo $rowbooking['coachusername']; ?>">
                <input type="hidden" name="bookingid" value="<?php echo $rowbooking['booking_id']; ?>">
                <input type="hidden" name="bookingdate" value="<?php echo $rowbooking['booking_date']; ?>">
                <input type="hidden" name="bookingtime" value="<?php echo $rowbooking['booking_time']; ?>">
                <?php 
                if ($type === 'player') {
                        if ($rowbooking['has_paid'] === 'Y') {
                             }
                             else if($rowbooking['has_paid'] === 'N') {
                                echo "<input type='submit' value='Change booking'>" . "</form>";      
                             }    
                }
                else if ($type === 'coach') {
                  echo "</form>";
                }
                ?>
                <form action="paymentpage.php" method="post">
                <input type="hidden" name="coachusername" value="<?php echo $rowbooking['coachusername']; ?>">
                <input type="hidden" name="bookingid" value="<?php echo $rowbooking['booking_id']; ?>">
                <input type="hidden" name="bookingdate" value="<?php echo $rowbooking['booking_date']; ?>">
                <input type="hidden" name="bookingtime" value="<?php echo $rowbooking['booking_time']; ?>">
                <?php

                if ($type === 'player') {
                        if ($rowbooking['has_paid'] === 'Y') {
                           echo "Awaiting completion" . "<br>";     
                        }
                        else if($rowbooking['has_paid'] === 'N') {
                           echo "<input type='submit' value='Pay for booking'>" . "</form>  <br> <br>";     
                        } 
                }
                
                else if ($type === 'coach') {
                        if ($rowbooking['has_paid'] === 'N') {
                                echo "Awaiting Payment";     
                             }
                             else if($rowbooking['has_paid'] === 'Y') {
                                echo "</form> <br>";
                                ?>
                                <form action='completion.pro.php' method='post'>
                                <input type="hidden" name="bookingid" value="<?php echo $rowbooking['booking_id']; ?>">
                                <?php     
                                echo "<input type='submit' value='complete booking'>" . "</form> <br> <br>";    
                             }  
                }
                
        }
} else {
        echo "there are no ongoing bookings" . "<br>";
}

echo "</div> <div class='completed-booking'><h4> Completed Bookings</h4>" ;

if ($resultcompletedbooking ->num_rows > 0) {
        while ($rowbooking = $resultcompletedbooking->fetch_assoc()) {
                //echo "hello there is a booking" . "<br>";
                echo "Coach: " . $rowbooking['coachusername'] . "<br>" .
                "Player: " . $rowbooking['playerusername'] . "<br>" .
                "Date: " . $rowbooking['booking_date'] . "<br>" . 
                "Time: " . $rowbooking['booking_time'] . "<br>";
                if ($rowbooking['rating_given'] === NULL) {
                        if ($type === 'player') {
                                ?>
                                <span class="star-rating">
                                <label for="star1-<?php echo $rowbooking['booking_id']; ?>" color = 'yellow'><i class="fa fa-star"></i></label>
                                <input type="radio" id="star1-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>"
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="1" hidden>

                                <label for="star2-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star2-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="2" hidden>

                                <label for="star3-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star3-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="3" hidden>

                                <label for="star4-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star4-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="4" hidden>

                                <label for="star5-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star5-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="5" hidden>
                                </span>

                                <form action="rating.pro.php" method="post">
                                <input type="hidden" name="bookingid" value="<?php echo $rowbooking['booking_id']; ?>">
                                <input id="ratingBar-<?php echo $rowbooking['booking_id']; ?>" type="number" 
                                name="rating" value="0" min="1" max="5" hidden>
                                <input type="submit" value="Give rating">
                                </form>
                                <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
                                
                                <script>
                                //assigns labels to their inputs
                                var labels = document.getElementsByTagName('LABEL');
                                for (var i=0; i < labels.length; i++) {
                                        if (labels[i].htmlFor != '') {
                                                var elem = document.getElementById(labels[i].htmlFor);
                                                if (elem)
                                                elem.label = labels[i];

                                        }
                                }

                                var star1_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star1-<?php echo $rowbooking['booking_id']; ?>').label;
                                var star2_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star2-<?php echo $rowbooking['booking_id']; ?>').label;
                                var star3_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star3-<?php echo $rowbooking['booking_id']; ?>').label;
                                var star4_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star4-<?php echo $rowbooking['booking_id']; ?>').label;
                                var star5_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star5-<?php echo $rowbooking['booking_id']; ?>').label;
                                
                                star1_<?php echo $rowbooking['booking_id']; ?>.style.cursor = 'pointer';
                                star2_<?php echo $rowbooking['booking_id']; ?>.style.cursor = 'pointer';
                                star3_<?php echo $rowbooking['booking_id']; ?>.style.cursor = 'pointer';
                                star4_<?php echo $rowbooking['booking_id']; ?>.style.cursor = 'pointer';
                                star5_<?php echo $rowbooking['booking_id']; ?>.style.cursor = 'pointer';

                                function displayStarValue<?php echo $rowbooking['booking_id']; ?>() {
                                var ele = document.getElementsByName('rating-<?php echo $rowbooking['booking_id']; ?>');

                                for (i=0; i < ele.length; i++) {
                                if(ele[i].checked)
                                 document.getElementById("ratingBar-<?php echo $rowbooking['booking_id']; ?>").value 
                                = ele[i].value;

                                changeStarColors<?php echo $rowbooking['booking_id']; ?>()

                                         }
                                }

                                function changeStarColors<?php echo $rowbooking['booking_id']; ?>() {

                                        var starvalue = document.getElementById("ratingBar-<?php echo $rowbooking['booking_id']; ?>").value;

                                        if (starvalue == 1) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 2) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 3) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 4) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star4_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 5) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star4_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star5_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }    

                                }

                                function resetStarColors<?php echo $rowbooking['booking_id']; ?>() {
                                        star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star4_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star5_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                }
                                
                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();

                                </script>

                                <?php      
                        }
                        if ($type === 'coach') {
                                echo "Rating: Pending <br>";      
                        }
                        
                }
                else {
                  echo "Rating: " . $rowbooking['rating_given'] . "<br>";
                        ?>
                                <span class="star-rating">
                                <label for="star1-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star1-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>"
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="1" hidden>

                                <label for="star2-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star2-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="2" hidden>

                                <label for="star3-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star3-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="3" hidden>

                                <label for="star4-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star4-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="4" hidden>

                                <label for="star5-<?php echo $rowbooking['booking_id']; ?>"><i class="fa fa-star"></i></label>
                                <input type="radio" id="star5-<?php echo $rowbooking['booking_id']; ?>" name="rating-<?php echo $rowbooking['booking_id']; ?>" 
                                onclick="displayStarValue<?php echo $rowbooking['booking_id']; ?>()" value="5" hidden>
                                </span>
                                <br>

                        <script>

                        //assigns labels to their inputs
                        var labels = document.getElementsByTagName('LABEL');
                                for (var i=0; i < labels.length; i++) {
                                        if (labels[i].htmlFor != '') {
                                                var elem = document.getElementById(labels[i].htmlFor);
                                                if (elem)
                                                elem.label = labels[i];

                                        }
                                }

                        var star1_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star1-<?php echo $rowbooking['booking_id']; ?>').label;
                        var star2_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star2-<?php echo $rowbooking['booking_id']; ?>').label;
                        var star3_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star3-<?php echo $rowbooking['booking_id']; ?>').label;
                        var star4_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star4-<?php echo $rowbooking['booking_id']; ?>').label;
                        var star5_<?php echo $rowbooking['booking_id']; ?> = document.getElementById('star5-<?php echo $rowbooking['booking_id']; ?>').label;

                        function resetStarColors<?php echo $rowbooking['booking_id']; ?>() {
                                        star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star4_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                                        star5_<?php echo $rowbooking['booking_id']; ?>.style.color = 'white';
                        }

                        function setStarColors<?php echo $rowbooking['booking_id']; ?>() {
                                var starvalue = "<?php echo $rowbooking['rating_given']; ?>";

                                if (starvalue == 1) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 2) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 3) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 4) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star4_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                                        else if (starvalue == 5) {
                                                resetStarColors<?php echo $rowbooking['booking_id']; ?>();
                                                star1_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star2_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star3_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star4_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                                star5_<?php echo $rowbooking['booking_id']; ?>.style.color = 'yellow';
                                        }
                        }

                        setStarColors<?php echo $rowbooking['booking_id']; ?>();
                        </script>

                        <?php
                        echo "<br>";
                }
                
        }
} else {
        echo "there are no completed bookings" . "<br>";
}

echo "</div>";
?>

</html>