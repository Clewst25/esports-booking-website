<?php
require "config.php";
include "header.php";

$coachid = $_SESSION["rating_coach"];

$searchbookings =  "SELECT * FROM booking WHERE coach_id = $coachid";

echo "coach id: " . $coachid; 

$resultbookings = $conn->query($searchbookings);

if ($resultbookings ->num_rows > 0) {  
    //this is searching for the correct coach id and pasting their data
    echo "<br> values: ";
    $total = 0;
        while($rowbookings = $resultbookings->fetch_assoc()) {
            echo $rowbookings['rating_given'] . " " ;
            $total = $total + $rowbookings['rating_given'];
            } 
        }

$items = $resultbookings->num_rows;

echo "<br> number of rows: " . $items;
echo "<br> total: " . $total;

$average = $total / $items;

$average = round($average, 2);

echo "<br> average: " . $average;

$updaterating = "UPDATE coach
SET rating = '$average'
WHERE coach_id = '$coachid' ";

if ($conn->query($updaterating) === TRUE) {
    unset($_SESSION["rating_coach"]);
    header("Location: personalpage.php");
    exit();
} else {
    header("Location: index.php");
    echo "something wrong";
}



$conn->close();
?>