<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "steve";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else{
  //checks that database is connected
  //echo "Console.log(Connected successfully)";
}

//create table

  //if ($conn->query($sql) === TRUE) {
    //
    //echo "Table MyGuests created successfully";
  //} else {
    //echo "Error creating table: " . $conn->error;
  //}

//mysqli_close($conn);
?>