<?php
require "config.php";
include "header.php";

//data from timetable form
$type = $_SESSION['signuptype'];

$inputtimezone = $_SESSION["timezone"];
$sunstart = $_SESSION['sun_start'];
$sunend = $_SESSION['sun_end'];
$monstart = $_SESSION['mon_start'];
$monend = $_SESSION['mon_end'];
$tuestart = $_SESSION['tue_start'];
$tueend = $_SESSION['tue_end'];
$wedstart = $_SESSION['wed_start'];
$wedend = $_SESSION['wed_end'];
$thustart = $_SESSION['thu_start'];
$thuend = $_SESSION['thu_end'];
$fristart = $_SESSION['fri_start'];
$friend = $_SESSION['fri_end'];
$satstart = $_SESSION['sat_start'];
$satend = $_SESSION['sat_end'];

/*
echo "this is what the sessions look like" . "<br>" .
$type . "<br>" .
$inputtimezone . "<br>" .
$sunstart . "-" . $sunend . "<br>" .
$monstart . "-" . $monend . "<br>" .
$tuestart . "-" . $tueend . "<br>" .
$wedstart . "-" . $wedend . "<br>" .
$thustart . "-" . $thuend . "<br>" .
$fristart . "-" . $friend . "<br>" .
$satstart . "-" . $satend . "<br>" .
*/

//queries

$searchtimezone = "SELECT timezone_id, timezone_name, timezone_offset FROM timezone";
$searchcoachid = "SELECT coach_id, username FROM coach ORDER BY coach_id DESC LIMIT 1";
$searchplayerid = "SELECT player_id, username FROM player ORDER BY player_id DESC LIMIT 1";
$searchtimetable = "SELECT * FROM timetable";

$resulttimezone = $conn->query($searchtimezone);
$resultcoachid = $conn->query($searchcoachid);
$resultplayerid = $conn->query($searchplayerid);
$resulttimetable = $conn->query($searchtimetable);

//this is checking all timezones with the entered timezone
while($rowzone = $resulttimezone->fetch_assoc()){
    if ($rowzone["timezone_offset"] === $inputtimezone){
      $timezone = $rowzone["timezone_id"];
      echo $timezone;
    break;
    }
    else {
    }
  }

//checks if it is a coach or a player
if ($type === "coach") {
    $insertfield = "coach_id";
    while($rowcoach = $resultcoachid->fetch_assoc()){
        $lastid = $rowcoach["coach_id"];
        //echo $lastid . " " . $rowcoach["username"] . "<br>";
        }
}
else if ($type === "player") {
    $insertfield = "player_id";
    while($rowplayer = $resultplayerid->fetch_assoc()){
        $lastid = $rowplayer["player_id"];
        //echo $lastid . " " . $rowplayer["username"] . "<br>";
        }

}

while($rowtimetable = $resulttimetable->fetch_assoc()){
  if ($rowtimetable[$insertfield] === $lastid){
    $error = "Sorry this user already has a timetable";
    $errorcheck = false;
    //echo "sorry this username already exists" . "<br>";
    break;
  } else {
    $errorcheck = true;
  }
}


$createtimetable ="INSERT INTO timetable ($insertfield, timezone_id, sunday_start_time, sunday_end_time, monday_start_time, monday_end_time, 
tuesday_start_time, tuesday_end_time, wednesday_start_time, wednesday_end_time,
thursday_start_time, thursday_end_time, friday_start_time, friday_end_time, saturday_start_time, saturday_end_time)
VALUES (
'$lastid',
'$timezone',
'$sunstart',
'$sunend',
'$monstart',
'$monend',
'$tuestart',
'$tueend',
'$wedstart',
'$wedend',
'$thustart',
'$thuend',
'$fristart',
'$friend',
'$satstart',
'$satend' )";

if ($conn->query($createtimetable) === TRUE) {
    echo "timetable should be created";
    //timetable is created
      //removing all the timetable sessions
      unset($_SESSION["timezone"]);
      unset($_SESSION["signuptype"]);
      unset($_SESSION["sun_start"]);
      unset($_SESSION["sun_end"]);
      unset($_SESSION["mon_start"]);
      unset($_SESSION["mon_end"]);
      unset($_SESSION["tue_start"]);
      unset($_SESSION["tue_end"]);
      unset($_SESSION["wed_start"]);
      unset($_SESSION["wed_end"]);
      unset($_SESSION["thu_start"]);
      unset($_SESSION["thu_end"]);
      unset($_SESSION["fri_start"]);
      unset($_SESSION["fri_end"]);
      unset($_SESSION["sat_start"]);
      unset($_SESSION["sat_end"]);
      //return user to the loginpage
      header("Location: loginpage.php");
      exit();
    }
    else {
        //the timetable is not created
        header("Location: loginpage.php");
    }


?>