<?php
require "config.php";
include "header.php";

$username = $_SESSION['username'];
$type = $_SESSION["type"];
$id = $_SESSION["id"];

if(isset($_POST['regioncoach'])){
    $newregion = $_POST['regioncoach'];
} else {
    $newregion = "Name not set in post method";
}
if(isset($_POST['gamescoach'])){
  $newgame = $_POST['gamescoach'];
} else {
  $newgame = "Name not set in post method";
}

$searchcoach = "SELECT * FROM coach WHERE coach_id = $id";
$searchregion = "SELECT * FROM region";
$searchgame = "SELECT * FROM games";
$resultcoach = $conn->query($searchcoach);
$resultregion = $conn->query($searchregion);
$resultgame = $conn->query($searchgame);

while($rowregion = $resultregion->fetch_assoc()){
        if ($rowregion["region_name"] === $newregion){
                $region = $rowregion["region_id"];
                //echo $region;
                break;
        }
        else {
        }
}

while($rowgame = $resultgame->fetch_assoc()){
        if ($rowgame["games_name"] === $newgame){
          $game = $rowgame["games_id"];
          //echo $game;
          break;
        }
        else {
        }
      }

$updatecoach = "UPDATE coach 
SET region_id = '$region',
games_id = '$game',
description = '$_POST[description]'
WHERE coach_id = '$id' ";


if ($conn->query($updatecoach) === TRUE) {
        header("Location: personalpage.php");
        exit();
      } else {
        header("Location: editpage.php");
      }

$conn->close();
?>