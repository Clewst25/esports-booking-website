<?php
require "config.php";
include "header.php";

$bookingid = $_POST["bookingid"];
$rating = $_POST["rating"];

echo $rating;

$searchbooking = "SELECT * FROM booking WHERE booking_id = $bookingid";

$resultbooking = $conn->query($searchbooking);

if ($resultbooking ->num_rows > 0) {  
    //this is searching for the correct coach id and pasting their data
        while($rowbooking = $resultbooking->fetch_assoc()) {
            echo $rowbooking['coach_id'];
            $_SESSION["rating_coach"] = $rowbooking['coach_id'];
            } 
        }


$updatebooking = "UPDATE booking
SET rating_given = '$rating'
WHERE booking_id = '$bookingid' ";


if ($conn->query($updatebooking) === TRUE) {
    header("Location: averagerating.pro.php");
    exit();
} else {
    header("Location: personalpage.php");
    echo "something wrong";
}

$conn->close();
?>