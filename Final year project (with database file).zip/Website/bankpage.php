<!DOCTYPE html>
<?php
require "config.php";
include "header.php";

?>

<head>
        <title>my php page</title>
</head>

<body>

<?php

echo $_POST['coachname'];
echo $_POST['bookingid'];

?>
<form>

<label>Name on Card</label>
<input></input> <br>

<label>Credit card number</label>
<input></input> <br>

<label>Exp Month</label>
<input></input> <br>

<label>CVV</label>
<input></input> <br>

<label>Exp Year</label>
<input></input> <br>

<label>Name on Card</label>
<input></input> <br>

</form>

<form action="payment.pro.php" method="post">

<input name="bookingid" value="<?php echo $_POST['bookingid']; ?>" hidden></input>

<input type="submit"></input>
</form>
</body>


<?php
//include "footer.php";
?>
</html>