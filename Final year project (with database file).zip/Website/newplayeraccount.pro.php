<?php
require "config.php";
include "header.php";

//data from forms
$inputusername = $_POST['username'];
$inputpassword = $_POST['password'];
$confirmpassword = $_POST['confirmpassword'];

//queries
$searchusername = "SELECT * FROM player";
$searchregion = "SELECT region_id, region_name FROM region";
$resultuser = $conn->query($searchusername);
$resultregion = $conn->query($searchregion);

//sessions for the timetable data
$_SESSION["timezone"] = $_POST['timezone'];

$_SESSION["signuptype"] = "player";

$_SESSION["sun_start"] = $_POST['sun_start'];
$_SESSION["sun_end"] = $_POST['sun_end'];
$_SESSION["mon_start"] = $_POST['mon_start'];
$_SESSION["mon_end"] = $_POST['mon_end'];
$_SESSION["tue_start"] = $_POST['tue_start'];
$_SESSION["tue_end"] = $_POST['tue_end'];
$_SESSION["wed_start"] = $_POST['wed_start'];
$_SESSION["wed_end"] = $_POST['wed_end'];
$_SESSION["thu_start"] = $_POST['thu_start'];
$_SESSION["thu_end"] = $_POST['thu_end'];
$_SESSION["fri_start"] = $_POST['fri_start'];
$_SESSION["fri_end"] = $_POST['fri_end'];
$_SESSION["sat_start"] = $_POST['sat_start'];
$_SESSION["sat_end"] = $_POST['sat_end'];


//this is checking all regions with the entered region
while($rowregion = $resultregion->fetch_assoc()){
  if ($rowregion["region_name"] === $_POST['region']){
    $region = $rowregion["region_id"];
    break;
  }
  else {
  }
}

//this is the template for entering in a new player
$createnewuser = "INSERT INTO player (username, password, region_id)
VALUES ('$inputusername',
'$inputpassword',
'$region')";

//checks if entered username is already in the database
while($rowuser = $resultuser->fetch_assoc()){
  if ($rowuser["username"] === $inputusername){
    $error = "Sorry this username already exists";
    $errorcheck = false;
    //echo "sorry this username already exists" . "<br>";
    break;
  } else {
    $errorcheck = true;
  }
}

//checks if there are no errors
if ($errorcheck === true){
  //starts the session
  if (session_id() == ''){
    session_start();
  }
    //adds the new player to the database
      if ($conn->query($createnewuser) === TRUE) {
        //the user is created!
      } else {
       //something went wrong with the query
     }
     //this returns the user to the login page
     unset($_SESSION["loginerr"]);
     header("Location: newtimetable.pro.php");
     exit();
     //if there are errors
    } else {
      //returns user to the signup page
      header("Location: signuppage.php");
      $_SESSION["loginerr"] = $error;
}

$conn->close();
?>