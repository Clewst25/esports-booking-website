<?php
require "config.php";
include "header.php";

//data from forms

$sundaystart = $_POST['sun_start'];
$sundayend = $_POST['sun_end'];

$mondaystart = $_POST['mon_start'];
$mondayend = $_POST['mon_end'];

$tuesdaystart = $_POST['tue_start'];
$tuesdayend = $_POST['tue_end'];

$wednesdaystart = $_POST['wed_start'];
$wednesdayend = $_POST['wed_end'];

$thursdaystart = $_POST['thu_start'];
$thursdayend = $_POST['thu_end'];

$fridaystart = $_POST['fri_start'];
$fridayend = $_POST['fri_end'];

$saturdaystart = $_POST['sat_start'];
$saturdayend = $_POST['sat_end'];

$timezone = $_POST['timezoneselect'];

$searchtimezone = "SELECT * FROM timezone WHERE timezone_offset = $timezone";

$resulttimezone = $conn->query($searchtimezone);

if ($resulttimezone ->num_rows > 0) {
    while ($rowtable = $resulttimezone->fetch_assoc()){
        $timeid = $rowtable['timezone_id'];
        echo $timeid;
    }
}

//session data

$id = $_SESSION["id"];
$type = $_SESSION["type"];

/*
echo "sunday: " . $sundaystart . "-" . $sundayend ."<br>" .
"monday: " . $mondaystart . "-" . $mondayend . "<br>" .
"tuesday: " . $tuesdaystart . "-" . $tuesdayend . "<br>" .
"wednesday: " . $wednesdaystart . "-" . $wednesdayend . "<br>" .
"thursday: " . $thursdaystart . "-" . $thursdayend . "<br>" .
"friday: " . $fridaystart . "-" . $fridayend . "<br>" . 
"saturday: " . $saturdaystart . "-" . $saturdayend . "<br>";
*/

//this checks if the timetable is for a player or a coach

//echo $type;

if ($type === "coach"){
    $filter = "WHERE coach_id = '$id'";
    //echo $filter;
}

if ($type === "player"){
    $filter = "WHERE player_id = '$id'";
    //echo $filter;
}

//$searchtimetable = "SELECT * FROM timetable $filter";
//$result = $conn->query($searchtimetable);

$updatetimetable = "UPDATE timetable 
SET timezone_id = '$timeid',
sunday_start_time = '$sundaystart',
sunday_end_time = '$sundayend',
monday_start_time = '$mondaystart',
monday_end_time = '$mondayend',
tuesday_start_time = '$tuesdaystart',
tuesday_end_time = '$tuesdayend',
wednesday_start_time = '$wednesdaystart',
wednesday_end_time = '$wednesdayend',
thursday_start_time = '$thursdaystart',
thursday_end_time = '$thursdayend',
friday_start_time = '$fridaystart',
friday_end_time = '$fridayend',
saturday_start_time = '$saturdaystart',
saturday_end_time = '$saturdayend'
$filter";

if ($conn->query($updatetimetable) === TRUE) {
    header("Location: personalpage.php");
    //echo "timetable changed!";
    exit();
  } else {
    header("Location: editpage.php");
    //echo "error timetable was not changed";
  }

$conn->close();

?>