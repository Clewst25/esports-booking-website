<?php
require "config.php";
include "header.php";

$bookingid = $_POST["bookingid"];

$searchbooking = "SELECT * FROM booking WHERE booking_id = $bookingid";

$resultbooking = $conn->query($searchbooking);

$updatebooking = "UPDATE booking
SET is_completed = 'Y'
WHERE booking_id = '$bookingid' ";

if ($conn->query($updatebooking) === TRUE) {
    header("Location: personalpage.php");
    exit();
} else {
    header("Location: editbooking.php");
}

$conn->close();
?>