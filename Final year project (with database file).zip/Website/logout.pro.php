<?php
    session_start();
    unset($_SESSION["username"]);
    unset($_SESSION["password"]);
    unset($_SESSION["type"]);
    unset($_SESSION["id"]);
    echo 'you have cleaned session';

    header("Location: index.php");

?>