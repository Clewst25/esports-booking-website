<?php
require "config.php";
include "header.php";

$bookingid = $_POST["bookingid"];

$searchbooking = "SELECT * FROM booking WHERE booking_id = $bookingid";

$resultbooking = $conn->query($searchbooking);

$updatebooking = "UPDATE booking
SET has_paid = 'Y'
WHERE booking_id = '$bookingid' ";

if ($conn->query($updatebooking) === TRUE) {
    header("Location: personalpage.php");
    exit();
} else {
    header("Location: editbooking.php");
}

$conn->close();
?>