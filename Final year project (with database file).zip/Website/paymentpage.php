<!DOCTYPE html>
<?php
require "config.php";
include "header.php";

$coachname = $_POST['coachusername'];
$bookingid = $_POST['bookingid'];

$searchcoach = "SELECT * FROM coach 
INNER JOIN payment_type ON coach.payment_type_id = payment_type.payment_type_id 
WHERE username = '$coachname'";

$resultcoach = $conn->query($searchcoach);

?>

<head>
        <title>my php page</title>
</head>

<body>

<?php

echo "<h1>Payment</h1>";


while($rowcoach = $resultcoach->fetch_assoc()) {
    echo "Coach: " . $rowcoach['username'] . "<br>";
    echo "&pound;" . $rowcoach['payment_price'] . " " . $rowcoach['payment_type'];
    ?>
    <form action="bankpage.php" method="post">
    <label for="number">
    
    </label>
    
    <?php
    if ($rowcoach['payment_type'] === "Per Session") {
        echo "<label for='number'>" . "" . "</label>";
        
        echo "<input id='number' type='number' value='1' onchange='sumUp()' hidden</input>";
    }
    else if ($rowcoach['payment_type'] === "Per Game") {
        echo "<label for='number'>" . "Number of Games: " . "</label>";
        echo "<input id='number' type='number' value='1' min='1' max='5' onchange='sumUp()' </input>";
    }
    else if ($rowcoach['payment_type'] === "Per Hour") {
        echo "<label for='number'>" . "Number of Hours: " . "</label>";
        echo "<input id='number' type='number' value='1' min='1' max='3' onchange='sumUp()' </input>";
    }
    ?>
    <input id="value" value="<?php echo $rowcoach['payment_price'] ?>" hidden> </input>
    
    <input id="total" name="total" hidden></input> <br>

    <input name="coachname" value="<?php echo $coachname ?>" hidden>

    <input name="bookingid" value="<?php echo $bookingid ?>" hidden>

    <a id="payment-text">Payment: X</a> <br>
    
    <input type="submit"></input>
    </form>
    <script>

    function sumUp() {
        var numb = document.getElementById("number");
        var price = document.getElementById("value");
        var total = document.getElementById("total");
        var payment = document.getElementById("payment-text");

        var sum = numb.value * price.value;

        total.value = sum;
        payment.innerHTML = "Payment: &pound;" + sum;
    }

    sumUp();
    </script>
    </form>
    <?php
}



?>
</body>


<?php
//include "footer.php";
?>
</html>