<?php
require "config.php";
include "header.php";

$datebooked = $_POST["selecteddate"];

$playername = $_POST["playername"];
$coachname = $_POST["coachname"];
$timebooked = $_POST["booking-time"];

$searchcoach = "SELECT coach_id, username, password FROM coach WHERE username = '$coachname'";
$searchplayer = "SELECT player_id, username, password FROM player WHERE username = '$playername'";

$resultcoach = $conn->query($searchcoach);
$resultplayer = $conn->query($searchplayer);

if ($resultcoach ->num_rows > 0) {  
    //this is searching for the correct coach id and pasting their data
      while($rowcoach = $resultcoach->fetch_assoc()) {
            if ($coachname === $rowcoach['username']){
                $coachid = $rowcoach['coach_id'];
                echo "coach id:" . $coachid . "<br>";
            break;
            } 
            else {
                    //echo "skipped username";
            }
        }
    }

if ($resultplayer ->num_rows > 0) {  
    //this is searching for the correct coach id and pasting their data
        while($rowplayer = $resultplayer->fetch_assoc()) {
            if ($playername === $rowplayer['username']){
                $playerid = $rowplayer['player_id'];
                echo "player id:" . $playerid . "<br>";
            break;
            } 
            else {
                //echo "skipped username";
            }
        }
    }

//echo "date booked " . $datebooked . " " . $timebooked;

$createnewbooking = "INSERT INTO booking (player_id, coach_id, booking_date, booking_time, has_paid, is_completed)
VALUES ('$playerid',
'$coachid',
'$datebooked',
'$timebooked',
'N',
'N')";

if ($conn->query($createnewbooking) === TRUE) {
    //echo "a new booking is created!";
    header("Location: personalpage.php");
    alert("new booking created!");
} else {
    //echo "uh oh the booking wasnt created!";
    header("Location: personalpage.php");
    alert("new booking not created!");
}

$conn->close();
?>