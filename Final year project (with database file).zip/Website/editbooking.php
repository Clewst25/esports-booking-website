<!DOCTYPE html>

<title>Profile page</title>
        <meta charset="UTF-8">

<?php
require "config.php";
include "header.php";

$coachname = $_POST["coachusername"];
$bookingid = $_POST["bookingid"];
$bookingdate = $_POST["bookingdate"];
$bookingtime = $_POST["bookingtime"];

$playername = $_SESSION['username'];

//the timetable query
$searchtimetable = "SELECT * from ((timetable
INNER JOIN timezone ON timetable.timezone_id = timezone.timezone_id)
INNER JOIN coach ON timetable.coach_id = coach.coach_id)
WHERE username = '$coachname'";

$resulttimetable = $conn->query($searchtimetable);

$searchtimezone = "SELECT * from ((timetable
INNER JOIN timezone ON timetable.timezone_id = timezone.timezone_id)
INNER JOIN player ON timetable.player_id = player.player_id)
WHERE username = '$playername'";

$resulttimezone = $conn->query($searchtimezone);

if ($resulttimezone ->num_rows > 0) {
  while ($rowtable = $resulttimezone->fetch_assoc()) {
          //setting all the times to variables
          $playertimezone = $rowtable['timezone_name'];
          $playeroffset = $rowtable['timezone_offset'];

  } 
}

if ($resulttimetable ->num_rows > 0) {
        while ($rowtable = $resulttimetable->fetch_assoc()) {
                //setting all the times to variables                
                
                $coachtimezone = $rowtable['timezone_name'];
                $coachoffset = $rowtable['timezone_offset'];

                $difference = $playeroffset - $coachoffset;

                $adjust = $difference*60*60;

                $sundaystart = date('H:i' , strtotime($rowtable['sunday_start_time']));
                $sundayend = date('H:i' , strtotime($rowtable['sunday_end_time']));
                $mondaystart = date('H:i' , strtotime($rowtable['monday_start_time']));
                $mondayend = date('H:i' , strtotime($rowtable['monday_end_time']));
                $tuesdaystart = date('H:i' , strtotime($rowtable['tuesday_start_time']));
                $tuesdayend = date('H:i' , strtotime($rowtable['tuesday_end_time']));
                $wednesdaystart = date('H:i' , strtotime($rowtable['wednesday_start_time']));
                $wednesdayend = date('H:i' , strtotime($rowtable['wednesday_end_time']));
                $thursdaystart = date('H:i' , strtotime($rowtable['thursday_start_time']));
                $thursdayend = date('H:i' , strtotime($rowtable['thursday_end_time']));
                $fridaystart = date('H:i' , strtotime($rowtable['friday_start_time']));
                $fridayend = date('H:i' , strtotime($rowtable['friday_end_time']));
                $saturdaystart = date('H:i' , strtotime($rowtable['saturday_start_time']));
                $saturdayend = date('H:i' , strtotime($rowtable['saturday_end_time']));

                $sundaystartlocal = date('H:i' , strtotime($rowtable['sunday_start_time']) +$adjust);
                $sundayendlocal = date('H:i' , strtotime($rowtable['sunday_end_time']) +$adjust);
                $mondaystartlocal = date('H:i' , strtotime($rowtable['monday_start_time']) +$adjust);
                $mondayendlocal = date('H:i' , strtotime($rowtable['monday_end_time']) +$adjust);
                $tuesdaystartlocal = date('H:i' , strtotime($rowtable['tuesday_start_time']) +$adjust);
                $tuesdayendlocal = date('H:i' , strtotime($rowtable['tuesday_end_time']) +$adjust);
                $wednesdaystartlocal = date('H:i' , strtotime($rowtable['wednesday_start_time']) +$adjust);
                $wednesdayendlocal = date('H:i' , strtotime($rowtable['wednesday_end_time']) +$adjust);
                $thursdaystartlocal = date('H:i' , strtotime($rowtable['thursday_start_time']) +$adjust);
                $thursdayendlocal = date('H:i' , strtotime($rowtable['thursday_end_time']) +$adjust);
                $fridaystartlocal = date('H:i' , strtotime($rowtable['friday_start_time']) +$adjust);
                $fridayendlocal = date('H:i' , strtotime($rowtable['friday_end_time']) +$adjust);
                $saturdaystartlocal = date('H:i' , strtotime($rowtable['saturday_start_time']) +$adjust);
                $saturdayendlocal = date('H:i' , strtotime($rowtable['saturday_end_time']) +$adjust);

                
                echo "<div id='global'>" . "<h4>Coach Schedule</h4>" . 
                "Timezone: " . $coachtimezone . "<br>" .
                "Sunday: " . $sundaystart . "-" . $sundayend . "<br>" . 
                "Monday: " . $mondaystart . "-" . $mondayend . "<br>" . 
                "Tuesday: " . $tuesdaystart . "-" . $tuesdayend . "<br>" .
                "Wednesday: " . $wednesdaystart  . "-" . $wednesdayend . "<br>" .
                "Thursday: " . $thursdaystart . "-" . $thursdayend . "<br>" .
                "Friday: " . $fridaystart . "-" . $fridayend . "<br>" .
                "Saturday: " . $saturdaystart . "-" . $saturdayend . "<br>" .
                "<button onclick='timezonelocal()'>Convert to your timezone</button>" .
                "</div>";

                echo "<div id='local'>" ."<h4>Coach Schedule</h4>" . 
                "Timezone: " . $playertimezone . "<br>" .
                "Sunday: " . $sundaystartlocal . "-" . $sundayendlocal . "<br>" . 
                "Monday: " . $mondaystartlocal . "-" . $mondayendlocal . "<br>" . 
                "Tuesday: " . $tuesdaystartlocal . "-" . $tuesdayendlocal . "<br>" .
                "Wednesday: " . $wednesdaystartlocal  . "-" . $wednesdayendlocal . "<br>" .
                "Thursday: " . $thursdaystartlocal . "-" . $thursdayendlocal . "<br>" .
                "Friday: " . $fridaystartlocal . "-" . $fridayendlocal . "<br>" .
                "Saturday: " . $saturdaystartlocal . "-" . $saturdayendlocal . "<br>" . 
                "<button onclick='timezoneglobal()'>Convert back to original timezone</button>" .
                "</div>";

        } 
}

?>

<form action="updatebooking.pro.php" method="post">

<input name="playername" type="hidden" value="<?php echo $player; ?>">
<input name="coachname" type="hidden" value="<?php echo $coach; ?>">
<input name="bookingid" type="hidden" value="<?php echo $bookingid; ?>">

<h3> Select time </h3>

<input id="selecteddate" name="selecteddate" value="<?php echo $bookingdate;?>" onchange="weekdaycheck()" type="date" required> <br>

<a id="date"></a>

<a>Choose a time between <a id="min"></a> and <a id="max"></a> </a> <br>

<label for="booking-time"> Choose a time for your booking <input type="time" value="<?php echo $bookingtime; ?>" id="booking-time" name="booking-time" onchange="reversetimezone()" required>

<input id="global-time" name="global-time" type="time" hidden>
<input id="global-date" name="global-date" type="date" hidden>

<input type="submit">
</form>

<script>
//this makes the minium value of the date be today
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
 if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
today = yyyy+'-'+mm+'-'+dd;
document.getElementById("selecteddate").setAttribute("min", today);
document.getElementById("selecteddate").setAttribute("value", today);
//this changes the day of the week
function weekdaycheck() {
//the value of the date in the booking
  var d = new Date(document.getElementById("selecteddate").value);
  //var e = new Date(document.getElementById("globaldate").value);
//the min for the date
  var weekdaymin = new Array(7);
  weekdaymin[0] = "<?php echo $sundaystartlocal; ?>";
  weekdaymin[1] = "<?php echo $mondaystartlocal; ?>";
  weekdaymin[2] = "<?php echo $tuesdaystartlocal; ?>";
  weekdaymin[3] = "<?php echo $wednesdaystartlocal; ?>";
  weekdaymin[4] = "<?php echo $thursdaystartlocal; ?>";
  weekdaymin[5] = "<?php echo $fridaystartlocal; ?>";
  weekdaymin[6] = "<?php echo $saturdaystartlocal; ?>";
//the max for the date
  var weekdaymax = new Array(7);
  weekdaymax[0] = "<?php echo $sundayendlocal; ?>";
  weekdaymax[1] = "<?php echo $mondayendlocal; ?>";
  weekdaymax[2] = "<?php echo $tuesdayendlocal; ?>";
  weekdaymax[3] = "<?php echo $wednesdayendlocal; ?>";
  weekdaymax[4] = "<?php echo $thursdayendlocal; ?>";
  weekdaymax[5] = "<?php echo $fridayendlocal; ?>";
  weekdaymax[6] = "<?php echo $saturdayendlocal; ?>";
//finding the correct day for the inputed value
  var min = weekdaymin[d.getDay()];
  var max = weekdaymax[d.getDay()];

  switch (d.getDay()) {
    case 0:
      document.getElementById("date").innerHTML = "Sunday ";
      break;
    case 1:
      document.getElementById("date").innerHTML = "Monday ";
      break
    case 2:
      document.getElementById("date").innerHTML = "Tuesday ";
      break;
    case 3:
      document.getElementById("date").innerHTML = "Wednesday ";
      break;
    case 4:
      document.getElementById("date").innerHTML = "Thursday ";
      break;
    case 5:
      document.getElementById("date").innerHTML = "Friday ";
      break;
    case 6:
      document.getElementById("date").innerHTML = "Saturday ";
      break;
  }


  document.getElementById("min").innerHTML = min;
  document.getElementById("max").innerHTML = max;
  document.getElementById("booking-time").setAttribute("min", min);
  document.getElementById("booking-time").setAttribute("max", max);
  
  reversetimezone();
}

function reversetimezone() {
  var date = document.getElementById("selecteddate").value;
  var time = document.getElementById("booking-time").value;
  var offset = "<?php echo $difference; ?>";

  var hour = time.slice(0,2);
  var min = time.slice(3,5);

  var globalhour = hour - offset;

  var thedate = new Date(date);
  thedate.setHours(globalhour);
  thedate.setMinutes(min);

  var thetime = new Date(date);
  thetime.setHours(globalhour);
  thetime.setMinutes(min);

  var newyear = thedate.getFullYear();
  var newmonth = thedate.getMonth()+1;
  var newday = thedate.getDate();

  var newhour = thetime.getHours();
  var newminiutes = thetime.getMinutes();

  if(newday<10){
    newday='0'+newday
  }
  if(newmonth<10){
    newmonth='0'+newmonth
  }
  if (newminiutes<10){
    newminiutes='0'+newminiutes
  }
  if (newhour<10){
    newhour='0'+newhour
  }

  thedate = newyear+'-'+newmonth+'-'+newday;
  thetime = newhour+':'+newminiutes;

  document.getElementById("global-time").value = thetime;
  document.getElementById("global-date").value = thedate;
}

function timezonelocal() {
  document.getElementById("local").style.display="block";
  document.getElementById("global").style.display="none";
}
function timezoneglobal() {
  document.getElementById("local").style.display="none";
  document.getElementById("global").style.display="block";
}
</script>

<script>
weekdaycheck();
timezonelocal();
</script>


<?php
//include "footer.php";
?>

</html>
